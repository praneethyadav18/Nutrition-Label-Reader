"""Native Streamlit interface; shared business logic, no HTML/CSS injection."""
import streamlit as st
from src.business_logic import add_record, filter_records, summarize, compare_records, warning_flags
from src.validators import validate_record_dict
from src.storage import audit
from src.importer import import_csv
from src.exporters import export_markdown
from pathlib import Path

st.set_page_config(page_title="Nutrition Label Reader", page_icon="🥗", layout="wide")
st.title("🥗 Nutrition Label Reader")
st.caption("Local nutrition register • Compare • Summarize • Export")
rows=filter_records()
page=st.sidebar.radio("Navigation",["Dashboard","Add record","Browse & compare","Bulk import","Export"])
if page=="Dashboard":
    s=summarize(rows); a,b,c,d=st.columns(4); a.metric("Records",s.count); b.metric("Avg calories",f"{s.calories_avg:.1f} kcal"); c.metric("Avg sugar",f"{s.sugar_avg:.1f} g"); d.metric("Avg sodium",f"{s.sodium_avg:.1f} mg")
    st.write("#### Threshold indicators"); st.write(f"High sugar: **{s.high_sugar_count}** • High sodium: **{s.high_sodium_count}**")
    if rows: st.dataframe(rows, use_container_width=True)
    audit("Streamlit dashboard viewed")
elif page=="Add record":
    with st.form("record_form"):
        name=st.text_input("Product name"); category=st.selectbox("Category",["Dairy","Grains","Snacks","Beverages","Fruit","Other"])
        serving=st.number_input("Serving size (g)",min_value=0.1,max_value=5000.0,value=100.0)
        calories=st.number_input("Calories (kcal)",min_value=0.0,max_value=10000.0); protein=st.number_input("Protein (g)",min_value=0.0,max_value=1000.0); carbs=st.number_input("Carbs (g)",min_value=0.0,max_value=1000.0); sugar=st.number_input("Sugar (g)",min_value=0.0,max_value=1000.0); fat=st.number_input("Fat (g)",min_value=0.0,max_value=1000.0); sodium=st.number_input("Sodium (mg)",min_value=0.0,max_value=100000.0)
        submitted=st.form_submit_button("Save record")
    if submitted:
        try:
            r=add_record(dict(product_name=name,category=category,serving_size_g=serving,calories=calories,protein_g=protein,carbs_g=carbs,sugar_g=sugar,fat_g=fat,sodium_mg=sodium)); st.success("Saved successfully!")
            flags=warning_flags(r)
            if flags: st.warning(" • ".join(flags))
        except ValueError as exc: st.error(str(exc))
elif page=="Browse & compare":
    keyword=st.text_input("Search product"); category=st.selectbox("Category filter",["All"]+sorted({r["category"] for r in rows}))
    selected=filter_records(keyword,"" if category=="All" else category); metric=st.selectbox("Comparison metric",["calories","protein_g","carbs_g","sugar_g","fat_g","sodium_mg"])
    st.dataframe(compare_records(selected,metric),use_container_width=True); audit("Streamlit records browse")
elif page=="Bulk import":
    upload=st.file_uploader("Upload CSV",type=["csv"])
    if upload is not None:
        tmp=Path("data")/"streamlit_upload.csv"; tmp.parent.mkdir(exist_ok=True); tmp.write_bytes(upload.getvalue()); accepted,errors=import_csv(tmp); st.success(f"Accepted {len(accepted)} rows.")
        if errors: st.warning("Import errors"); st.code("\n".join(errors))
elif page=="Export":
    st.write("Export current dataset from the CLI to CSV and Markdown, or view audit log.")
    from src.storage import AUDIT_FILE
    if AUDIT_FILE.exists(): st.text(AUDIT_FILE.read_text(encoding="utf-8"))
