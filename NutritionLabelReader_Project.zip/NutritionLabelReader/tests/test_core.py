"""Core regression tests for validation, logic, persistence and indexes."""
import unittest, tempfile, json, sqlite3
from pathlib import Path
from unittest.mock import patch
from src.validators import validate_number, validate_name, validate_record_dict
from src.business_logic import summarize, warning_flags, compare_records
from src.storage import write_records, query_indexed, read_records

class CoreTests(unittest.TestCase):
    def test_validation_ranges(self):
        self.assertEqual(validate_number("calories",0),0)
        with self.assertRaises(ValueError): validate_number("calories",-1)
        with self.assertRaises(ValueError): validate_number("sodium_mg","abc")
        with self.assertRaises(ValueError): validate_name("")
    def test_record_validation(self):
        data=dict(product_name="Test snack",category="Snacks",serving_size_g=50,calories=100,protein_g=2,carbs_g=20,sugar_g=5,fat_g=3,sodium_mg=100)
        self.assertEqual(validate_record_dict(data)["category"],"Snacks")
    def test_summary_and_flags(self):
        rows=[dict(calories=100,protein_g=2,sugar_g=30,fat_g=3,sodium_mg=700),dict(calories=200,protein_g=4,sugar_g=2,fat_g=5,sodium_mg=20)]
        s=summarize(rows); self.assertEqual(s.count,2); self.assertEqual(s.calories_avg,150); self.assertEqual(s.high_sugar_count,1); self.assertEqual(s.high_sodium_count,1)
        self.assertEqual(len(warning_flags(rows[0])),2)
    def test_compare(self):
        rows=[dict(calories=90),dict(calories=40)]
        self.assertEqual(compare_records(rows,"calories")[0]["calories"],40)
    def test_index_creation_and_query(self):
        rows=read_records(); self.assertTrue(rows)
        result=query_indexed(category="Dairy"); self.assertTrue(result)
        with sqlite3.connect("data/nutrition.db") as db:
            indexes=[r[1] for r in db.execute("PRAGMA index_list(nutrition)")]
        self.assertIn("idx_category",indexes)
    def test_corruption_recovery_archives_backup(self):
        with tempfile.TemporaryDirectory() as td:
            d=Path(td); broken=d/"records.json"; broken.write_text("{bad json", encoding="utf-8")
            with patch("src.storage.DATA_DIR",d), patch("src.storage.JSON_FILE",broken), patch("src.storage.AUDIT_FILE",d/"audit.txt"), patch("src.storage.LOCK_FILE",d/"lock"):
                self.assertEqual(read_records(),[])
                self.assertFalse(broken.exists())
                self.assertTrue(list(d.glob("records.json.*.bak")))
    def test_seed_dataset(self):
        self.assertGreaterEqual(len(read_records()),35)

if __name__=="__main__": unittest.main()
