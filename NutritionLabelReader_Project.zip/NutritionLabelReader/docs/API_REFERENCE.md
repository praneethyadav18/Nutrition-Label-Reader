# API Reference — Nutrition Label Reader

## Modules

- `src.models`: `NutritionRecord` data class, `Category` enum, `Summary` aggregate model.
- `src.validators`: `validate_name`, `validate_category`, `validate_number`, `validate_record_dict`, `prompt_text`, `prompt_number`. Range validation rejects blank/non-numeric values and out-of-range numbers.
- `src.storage`: `read_records`, `write_records`, `file_lock`, `audit`, `query_indexed`. Persists JSON/CSV and synchronizes the indexed SQLite mirror.
- `src.business_logic`: `add_record`, `delete_record`, `filter_records`, `compare_records`, `summarize`, `warning_flags`.
- `src.importer`: `import_csv(path)` returns `(accepted_records, errors)`; errors are reported per row.
- `src.exporters`: `export_csv(rows,path)`, `export_markdown(rows,path)`, `export_audit(path)`.
- `src.ui`: `run_cli()` launches the menu-driven ANSI console UI.

## Record schema

`record_id` integer; `product_name` and `category` strings; `serving_size_g`, `calories`, `protein_g`, `carbs_g`, `sugar_g`, `fat_g`, and `sodium_mg` numeric; `created_at` ISO timestamp.

## Numeric constraints

- Serving size: 0.1–5000 g
- Calories: 0–10000 kcal
- Protein/carbs/sugar/fat: 0–1000 g
- Sodium: 0–100000 mg

## Analytics and warning thresholds

Summary reports count, averages, total calories, and counts of records meeting sugar (25 g) or sodium (600 mg) thresholds. Comparisons sort by a supported nutrition metric. These flags are simple label-reading indicators and are not medical advice.

## Storage and recovery

JSON is the canonical register, CSV is a synchronized export, and SQLite holds a mirror with product-name, category, and calorie indexes. Writes use temporary files and atomic replacement. Storage access uses a re-entrant thread lock and OS file lock. Corrupt JSON is archived with a timestamped `.bak` suffix and the application starts with an empty register.
