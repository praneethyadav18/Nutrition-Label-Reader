# 🥗 Nutrition Label Reader

A local-first nutrition-label register built from the **LocalImpact Challenge Project #70** brief. CLI and Streamlit share the `src/` backend. The CLI backend uses Python 3.10+ standard library only; Streamlit is the optional UI dependency.

## Run the Terminal CLI

```bash
python3.10 -m venv .venv
# Windows: .venv\\Scripts\\activate | macOS/Linux: source .venv/bin/activate
python main.py
```

## Run the Streamlit UI

```bash
pip install -r requirements.txt
streamlit run app_streamlit.py
```

## Demo data

The project includes 40 records in `data/records.json` and `data/records.csv`, plus an indexed SQLite mirror. To regenerate sample data: `python seed.py`.

## Features

- Add, search/filter, compare and delete nutrition records
- Defensive validation, ANSI paginated terminal tables and warning flags
- JSON and CSV persistence; SQLite indexed mirror
- CSV bulk import with row-specific errors
- Markdown, CSV and audit-log exports
- Corruption recovery, atomic writes, thread and OS file locking
- Unit tests and GitHub Actions CI

## Tests

```bash
python -m unittest discover -s tests -v
```

See `docs/API_REFERENCE.md` for module documentation.
