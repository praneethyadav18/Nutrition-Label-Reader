"""Input and record validation helpers."""
import re
from typing import Any

NAME_RE = re.compile(r"^[\w\s&'().,-]{1,80}$", re.UNICODE)
CATEGORY_RE = re.compile(r"^[\w\s-]{1,30}$")

LIMITS = {
    "serving_size_g": (0.1, 5000), "calories": (0, 10000),
    "protein_g": (0, 1000), "carbs_g": (0, 1000),
    "sugar_g": (0, 1000), "fat_g": (0, 1000), "sodium_mg": (0, 100000),
}

def validate_name(value: Any) -> str:
    text = str(value).strip()
    if not text or not NAME_RE.fullmatch(text):
        raise ValueError("Product name must be 1-80 permitted characters.")
    return text

def validate_category(value: Any) -> str:
    text = str(value).strip()
    if not text or not CATEGORY_RE.fullmatch(text):
        raise ValueError("Category must be a non-empty text value.")
    return text.title()

def validate_number(field: str, value: Any) -> float:
    if field not in LIMITS:
        raise ValueError(f"Unknown field: {field}")
    try:
        number = float(value)
    except (TypeError, ValueError):
        raise ValueError(f"{field} must be numeric.") from None
    low, high = LIMITS[field]
    if not (low <= number <= high):
        raise ValueError(f"{field} must be between {low} and {high}.")
    return number

def prompt_text(prompt: str, validator, *, default=None):
    while True:
        raw = input(prompt).strip()
        if not raw and default is not None:
            raw = str(default)
        try:
            return validator(raw)
        except ValueError as exc:
            print(f"Invalid input: {exc}")

def prompt_number(prompt: str, field: str, *, default=None) -> float:
    while True:
        raw = input(prompt).strip()
        if not raw and default is not None:
            raw = str(default)
        try:
            return validate_number(field, raw)
        except ValueError as exc:
            print(f"Invalid input: {exc}")

def validate_record_dict(row: dict) -> dict:
    result = {
        "product_name": validate_name(row.get("product_name", "")),
        "category": validate_category(row.get("category", "Other")),
    }
    for field in LIMITS:
        result[field] = validate_number(field, row.get(field, ""))
    return result
