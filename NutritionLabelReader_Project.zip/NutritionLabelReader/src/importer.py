"""CSV bulk importer with per-row error reporting."""
import csv
from pathlib import Path
from datetime import datetime
from .validators import validate_record_dict
from .storage import read_records, write_records, audit

REQUIRED = ["product_name","category","serving_size_g","calories","protein_g","carbs_g","sugar_g","fat_g","sodium_mg"]
def import_csv(path):
    existing = read_records(); next_id = max((int(r.get("record_id", 0)) for r in existing), default=0) + 1
    accepted, errors = [], []
    try:
        with Path(path).open(encoding="utf-8-sig", newline="") as f:
            reader = csv.DictReader(f)
            missing = [x for x in REQUIRED if x not in (reader.fieldnames or [])]
            if missing: return accepted, [f"Header missing required columns: {', '.join(missing)}"]
            for row_no, row in enumerate(reader, start=2):
                try:
                    clean = validate_record_dict(row)
                    clean.update(record_id=next_id, created_at=datetime.now().isoformat(timespec="seconds")); next_id += 1
                    accepted.append(clean)
                except ValueError as exc:
                    errors.append(f"Row {row_no}: {exc}")
    except OSError as exc:
        return accepted, [f"Could not read file: {exc}"]
    if accepted: existing.extend(accepted); write_records(existing)
    audit(f"CSV import: {len(accepted)} accepted, {len(errors)} rejected from {path}")
    return accepted, errors
