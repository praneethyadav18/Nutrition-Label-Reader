"""Locked, atomic local persistence and SQLite indexed mirror."""
import csv, json, os, sqlite3, tempfile, threading, time
from pathlib import Path
from contextlib import contextmanager

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
JSON_FILE = DATA_DIR / "records.json"
CSV_FILE = DATA_DIR / "records.csv"
DB_FILE = DATA_DIR / "nutrition.db"
AUDIT_FILE = DATA_DIR / "audit_log.txt"
LOCK_FILE = DATA_DIR / ".register.lock"
_FIELDS = ["record_id","product_name","category","serving_size_g","calories","protein_g","carbs_g","sugar_g","fat_g","sodium_mg","created_at"]
_thread_lock = threading.RLock()

@contextmanager
def file_lock():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    with _thread_lock, open(LOCK_FILE, "a+b") as lock:
        try:
            if os.name == "nt":
                import msvcrt
                lock.seek(0); msvcrt.locking(lock.fileno(), msvcrt.LK_LOCK, 1)
            else:
                import fcntl
                fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
            yield
        finally:
            try:
                if os.name == "nt":
                    import msvcrt
                    lock.seek(0); msvcrt.locking(lock.fileno(), msvcrt.LK_UNLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(lock.fileno(), fcntl.LOCK_UN)
            except OSError:
                pass

def audit(action: str):
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    with _thread_lock:
        with AUDIT_FILE.open("a", encoding="utf-8") as f:
            f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} | {action}\n")

def _atomic_write(path: Path, writer):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), prefix=path.name, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as stream:
            writer(stream); stream.flush(); os.fsync(stream.fileno())
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp): os.unlink(tmp)

def _archive_corrupt(path: Path):
    if path.exists():
        backup = path.with_name(path.name + time.strftime(".%Y%m%d_%H%M%S") + ".bak")
        os.replace(path, backup)
        audit(f"Archived corrupted {path.name} as {backup.name}")

def read_records():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    with file_lock():
        if not JSON_FILE.exists():
            return []
        try:
            with JSON_FILE.open(encoding="utf-8") as f:
                rows = json.load(f)
            if not isinstance(rows, list): raise ValueError("JSON register must be a list")
            return rows
        except (FileNotFoundError, json.JSONDecodeError, ValueError) as exc:
            _archive_corrupt(JSON_FILE); audit(f"Register recovery: {exc}")
            return []

def write_records(rows):
    with file_lock():
        _atomic_write(JSON_FILE, lambda f: json.dump(rows, f, indent=2, ensure_ascii=False))
        def csv_writer(f):
            w = csv.DictWriter(f, fieldnames=_FIELDS); w.writeheader(); w.writerows(rows)
        _atomic_write(CSV_FILE, csv_writer)
        _sync_sqlite(rows)

def _sync_sqlite(rows):
    with sqlite3.connect(DB_FILE) as db:
        db.execute("CREATE TABLE IF NOT EXISTS nutrition (record_id INTEGER PRIMARY KEY, product_name TEXT, category TEXT, serving_size_g REAL, calories REAL, protein_g REAL, carbs_g REAL, sugar_g REAL, fat_g REAL, sodium_mg REAL, created_at TEXT)")
        db.execute("CREATE INDEX IF NOT EXISTS idx_product_name ON nutrition(product_name)")
        db.execute("CREATE INDEX IF NOT EXISTS idx_category ON nutrition(category)")
        db.execute("CREATE INDEX IF NOT EXISTS idx_calories ON nutrition(calories)")
        db.execute("DELETE FROM nutrition")
        db.executemany("INSERT INTO nutrition VALUES (?,?,?,?,?,?,?,?,?,?,?)", [tuple(r.get(k) for k in _FIELDS) for r in rows])
        db.commit()

def query_indexed(keyword="", category=""):
    with sqlite3.connect(DB_FILE) as db:
        db.execute("CREATE TABLE IF NOT EXISTS nutrition (record_id INTEGER PRIMARY KEY, product_name TEXT, category TEXT, serving_size_g REAL, calories REAL, protein_g REAL, carbs_g REAL, sugar_g REAL, fat_g REAL, sodium_mg REAL, created_at TEXT)")
        db.execute("CREATE INDEX IF NOT EXISTS idx_product_name ON nutrition(product_name)")
        db.execute("CREATE INDEX IF NOT EXISTS idx_category ON nutrition(category)")
        where, params = [], []
        if keyword: where.append("product_name LIKE ?"); params.append(f"%{keyword}%")
        if category: where.append("category = ?"); params.append(category)
        sql = "SELECT * FROM nutrition" + (" WHERE " + " AND ".join(where) if where else "") + " ORDER BY record_id"
        return [dict(zip(_FIELDS, row)) for row in db.execute(sql, params).fetchall()]
