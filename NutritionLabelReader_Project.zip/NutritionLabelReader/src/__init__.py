"""Nutrition Label Reader shared backend."""
