"""Report export helpers."""
import csv
from pathlib import Path
from .business_logic import summarize
from .storage import AUDIT_FILE
FIELDS = ["record_id","product_name","category","serving_size_g","calories","protein_g","carbs_g","sugar_g","fat_g","sodium_mg","created_at"]
def export_csv(rows, path):
    p=Path(path); p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("w", encoding="utf-8", newline="") as f:
        w=csv.DictWriter(f, fieldnames=FIELDS); w.writeheader(); w.writerows(rows)
    return p
def export_markdown(rows, path):
    s=summarize(rows); p=Path(path); p.parent.mkdir(parents=True, exist_ok=True)
    text=f"# Nutrition Label Reader Report\n\nRecords: {s.count}\n\n| Metric | Average |\n|---|---:|\n| Calories | {s.calories_avg:.1f} kcal |\n| Protein | {s.protein_avg:.1f} g |\n| Sugar | {s.sugar_avg:.1f} g |\n| Fat | {s.fat_avg:.1f} g |\n| Sodium | {s.sodium_avg:.1f} mg |\n\nHigh sugar flags: {s.high_sugar_count}\n\nHigh sodium flags: {s.high_sodium_count}\n\n"
    text += "| Product | Category | Calories | Protein | Sugar | Sodium |\n|---|---|---:|---:|---:|---:|\n"
    text += "".join(f"| {r['product_name']} | {r['category']} | {r['calories']} | {r['protein_g']} | {r['sugar_g']} | {r['sodium_mg']} |\n" for r in rows)
    p.write_text(text, encoding="utf-8"); return p
def export_audit(path):
    p=Path(path); p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(AUDIT_FILE.read_text(encoding="utf-8") if AUDIT_FILE.exists() else "No audit entries yet.\n", encoding="utf-8"); return p
