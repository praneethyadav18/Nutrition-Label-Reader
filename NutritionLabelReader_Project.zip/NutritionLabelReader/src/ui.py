"""ANSI terminal UI and pagination."""
from .validators import prompt_text, prompt_number, validate_name, validate_category
from .business_logic import add_record, filter_records, summarize, compare_records, warning_flags, delete_record
from .exporters import export_csv, export_markdown, export_audit
from .importer import import_csv
from .storage import audit, ROOT

C={"reset":"\033[0m","cyan":"\033[36m","green":"\033[32m","yellow":"\033[33m","red":"\033[31m","bold":"\033[1m"}
def color(s, key): return C[key]+s+C["reset"]
def print_table(rows, page_size=10):
    if not rows: print("No records found."); return
    cols=[("ID","record_id",5),("Product","product_name",24),("Category","category",14),("kcal","calories",8),("Protein","protein_g",8),("Sugar","sugar_g",8),("Sodium","sodium_mg",9)]
    pages=[rows[i:i+page_size] for i in range(0,len(rows),page_size)]
    for i,page in enumerate(pages,1):
        print(" | ".join(h.ljust(w) for h,_,w in cols)); print("-"*90)
        for r in page: print(" | ".join(str(r.get(k,""))[:w].ljust(w) for _,k,w in cols))
        if len(pages)>1: input(f"Page {i}/{len(pages)} — press Enter to continue...")
def menu():
    print(color("\n NUTRITION LABEL READER ","cyan")); print("1. Add nutrition record\n2. Browse / search\n3. Compare products\n4. Executive summary\n5. Import CSV\n6. Export reports\n7. Delete record\n0. Exit")
def add_flow():
    data={"product_name":prompt_text("Product name: ",validate_name),"category":prompt_text("Category (Dairy/Grains/Snacks/Beverages/Fruit/Other): ",validate_category)}
    prompts=[("serving_size_g","Serving size (g): "),("calories","Calories (kcal): "),("protein_g","Protein (g): "),("carbs_g","Carbs (g): "),("sugar_g","Sugar (g): "),("fat_g","Fat (g): "),("sodium_mg","Sodium (mg): ")]
    for key,p in prompts: data[key]=prompt_number(p,key)
    record=add_record(data); print(color(f"Saved record #{record['record_id']}.","green"))
    flags=warning_flags(record)
    if flags: print(color("Warning: "+", ".join(flags),"yellow"))
def run_cli():
    audit("CLI launched")
    while True:
        menu(); choice=input("Select: ").strip()
        try:
            if choice=="1": add_flow()
            elif choice=="2":
                keyword=input("Product keyword (blank for all): ").strip(); category=input("Category (blank for all): ").strip()
                print_table(filter_records(keyword,category))
            elif choice=="3":
                rows=filter_records(); metric=input("Sort by calories/protein_g/sugar_g/fat_g/sodium_mg/carbs_g [calories]: ").strip() or "calories"
                print_table(compare_records(rows,metric)); audit(f"Compared records by {metric}")
            elif choice=="4":
                s=summarize(); print(f"Records: {s.count} | Average calories: {s.calories_avg:.1f} | Avg protein: {s.protein_avg:.1f} g | Avg sugar: {s.sugar_avg:.1f} g | Avg fat: {s.fat_avg:.1f} g | Avg sodium: {s.sodium_avg:.1f} mg\nTotal calories: {s.calories_total:.1f} | High-sugar flags: {s.high_sugar_count} | High-sodium flags: {s.high_sodium_count}"); audit("Summary viewed")
            elif choice=="5":
                path=input("CSV path: ").strip(); accepted,errors=import_csv(path); print(f"Imported {len(accepted)} rows."); [print(color(e,"red")) for e in errors]
            elif choice=="6":
                rows=filter_records(); out=ROOT/"exports"; out.mkdir(exist_ok=True)
                export_csv(rows,out/"report.csv"); export_markdown(rows,out/"report.md"); export_audit(out/"audit_log.txt"); print(f"Exported reports to {out}")
            elif choice=="7":
                raw=input("Record ID to delete: ").strip()
                try: print("Deleted." if delete_record(int(raw)) else "Record not found.")
                except ValueError: print("Please enter a numeric ID.")
            elif choice=="0": audit("CLI exited"); print("Goodbye!"); break
            else: print("Choose a listed menu option.")
        except (ValueError, OSError) as exc: print(color(f"Operation failed: {exc}","red"))
