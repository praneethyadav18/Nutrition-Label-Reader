"""Nutrition calculations, comparisons, filtering and threshold flags."""
from datetime import datetime
from .models import Summary
from .validators import validate_record_dict
from .storage import read_records, write_records, audit

HIGH_SUGAR_G = 25.0
HIGH_SODIUM_MG = 600.0

def add_record(data: dict) -> dict:
    clean = validate_record_dict(data)
    rows = read_records()
    record = {"record_id": max((int(r.get("record_id", 0)) for r in rows), default=0) + 1,
              **clean, "created_at": datetime.now().isoformat(timespec="seconds")}
    rows.append(record); write_records(rows); audit(f"Added record #{record['record_id']} ({record['product_name']})")
    return record

def delete_record(record_id: int) -> bool:
    rows = read_records(); new_rows = [r for r in rows if int(r.get("record_id", -1)) != record_id]
    if len(new_rows) == len(rows): return False
    write_records(new_rows); audit(f"Deleted record #{record_id}"); return True

def filter_records(keyword="", category=""):
    rows = read_records()
    return [r for r in rows if (not keyword or keyword.casefold() in r.get("product_name", "").casefold()) and (not category or r.get("category", "").casefold() == category.casefold())]

def compare_records(records, metric="calories"):
    if metric not in {"calories", "protein_g", "sugar_g", "fat_g", "sodium_mg", "carbs_g"}:
        raise ValueError("Unsupported comparison metric")
    return sorted(records, key=lambda r: float(r[metric]))

def summarize(records=None) -> Summary:
    rows = read_records() if records is None else records
    n = len(rows)
    avg = lambda key: sum(float(r[key]) for r in rows) / n if n else 0.0
    return Summary(n, avg("calories"), avg("protein_g"), avg("sugar_g"), avg("fat_g"), avg("sodium_mg"),
                   sum(float(r["calories"]) for r in rows), sum(float(r["sugar_g"]) >= HIGH_SUGAR_G for r in rows),
                   sum(float(r["sodium_mg"]) >= HIGH_SODIUM_MG for r in rows))

def warning_flags(record):
    flags=[]
    if float(record["sugar_g"]) >= HIGH_SUGAR_G: flags.append(f"High sugar (≥{HIGH_SUGAR_G:g} g)")
    if float(record["sodium_mg"]) >= HIGH_SODIUM_MG: flags.append(f"High sodium (≥{HIGH_SODIUM_MG:g} mg)")
    return flags
