"""Domain models for Nutrition Label Reader."""
from dataclasses import dataclass, asdict
from enum import Enum
from datetime import datetime

class Category(str, Enum):
    DAIRY = "Dairy"
    GRAIN = "Grains"
    SNACK = "Snacks"
    BEVERAGE = "Beverages"
    FRUIT = "Fruit"
    OTHER = "Other"

@dataclass
class NutritionRecord:
    record_id: int
    product_name: str
    category: str
    serving_size_g: float
    calories: float
    protein_g: float
    carbs_g: float
    sugar_g: float
    fat_g: float
    sodium_mg: float
    created_at: str

    def to_dict(self):
        return asdict(self)

    @classmethod
    def from_dict(cls, data):
        return cls(**data)

@dataclass
class Summary:
    count: int
    calories_avg: float
    protein_avg: float
    sugar_avg: float
    fat_avg: float
    sodium_avg: float
    calories_total: float
    high_sugar_count: int
    high_sodium_count: int
