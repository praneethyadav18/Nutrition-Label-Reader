"""Generate the bundled 40-record sample dataset."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
from src.storage import write_records
from datetime import datetime
names=[("Plain Yogurt","Dairy"),("Whole Milk","Dairy"),("Cheddar","Dairy"),("Oat Cereal","Grains"),("Whole Wheat Bread","Grains"),("Granola","Grains"),("Potato Chips","Snacks"),("Dark Chocolate","Snacks"),("Crackers","Snacks"),("Orange Juice","Beverages"),("Cola","Beverages"),("Sparkling Water","Beverages"),("Apple","Fruit"),("Banana","Fruit"),("Pear","Fruit"),("Protein Bar","Snacks"),("Rice Cakes","Grains"),("Peanut Butter","Other"),("Almonds","Other"),("Lentil Soup","Other")]
rows=[]
for i in range(40):
    n,c=names[i%len(names)]; factor=1+(i%7)*.17
    rows.append(dict(record_id=i+1,product_name=f"{n} {i//20+1}" if i>=20 else n,category=c,serving_size_g=100.0,calories=round((60+i*9)*factor,1),protein_g=round((1+i%13)*factor,1),carbs_g=round((5+i%23)*factor,1),sugar_g=round((2+i%32)*factor,1),fat_g=round((1+i%17)*factor,1),sodium_mg=round((30+i*28)*factor,1),created_at=datetime.now().isoformat(timespec="seconds")))
# Include boundary cases (low zero values and upper legal ranges)
rows[0].update(calories=0,protein_g=0,carbs_g=0,sugar_g=0,fat_g=0,sodium_mg=0)
rows[-1].update(serving_size_g=5000,calories=10000,protein_g=1000,carbs_g=1000,sugar_g=1000,fat_g=1000,sodium_mg=100000)
write_records(rows)
print("Seeded 40 records")
