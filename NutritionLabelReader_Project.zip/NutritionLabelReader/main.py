"""Terminal entry point."""
from src.ui import run_cli
if __name__ == "__main__": run_cli()
